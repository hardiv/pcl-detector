# Data

This directory contains the training data and official SemEval-2022 Task 4 splits for the **Don't Patronize Me!** PCL detection dataset.

## Directory Structure

```
data/
├── train/
│   ├── dontpatronizeme_categories.tsv   # PCL multilabel classification dataset (v1.5)
│   ├── dontpatronizeme_categories copy.tsv
│   └── README.txt                       # Original dataset README from the corpus authors
└── splits/
    ├── train_semeval_parids-labels.csv  # Official SemEval-2022 training split (8,376 examples)
    └── dev_semeval_parids-labels.csv    # Official SemEval-2022 dev split (2,095 examples)
```

## Files

### `train/dontpatronizeme_categories.tsv`

The PCL multilabel classification dataset. Each row represents an annotated PCL span within a paragraph. Fields (tab-separated, data starts at line 5):

| Field | Description |
|---|---|
| `par_id` | Unique paragraph ID (matches IDs in the PCL binary dataset) |
| `art_id` | Document ID in the NOW corpus |
| `text` | Full paragraph text |
| `keyword` | Search term used to retrieve the text (target community) |
| `country_code` | Two-letter ISO Alpha-2 code for the source media outlet |
| `span_start` | Start character position of the identified PCL span |
| `span_finish` | End character position of the identified PCL span |
| `span_text` | The text snippet identified as PCL |
| `pcl_category` | PCL category label for the span |
| `number_of_annotators` | Number of annotators agreeing on the category (1 or 2) |

### `splits/train_semeval_parids-labels.csv` and `splits/dev_semeval_parids-labels.csv`

Official SemEval-2022 Task 4 train/dev splits. Each row maps a paragraph to a 7-dimensional binary label vector:

| Field | Description |
|---|---|
| `par_id` | Paragraph ID (join key to the `.tsv` files above) |
| `label` | 7-element binary list, one entry per PCL category |

## Source

Dataset from SemEval-2022 Task 4: Patronizing and Condescending Language Detection.
- Task website: https://sites.google.com/view/pcl-detection-semeval2022/
- GitHub: https://github.com/Perez-AlmendrosC/dontpatronizeme
